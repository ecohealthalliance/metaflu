#' metaflu.- Stochastic simulator for avian influenza metapopulation dynaimics
#'
#' @name metaflu
#' @docType package
NULL

#' @useDynLib metaflu
#' @importFrom Rcpp sourceCpp
NULL
