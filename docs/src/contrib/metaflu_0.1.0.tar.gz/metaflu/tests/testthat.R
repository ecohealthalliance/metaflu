library(testthat)
library(metaflu)

test_check("metaflu")
