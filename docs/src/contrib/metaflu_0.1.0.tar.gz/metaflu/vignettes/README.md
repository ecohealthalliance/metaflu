# ASL 2050 Avian Influenza Notebook

This directory contains interim notes and analyses done over the course of
this project. These should R markdown files, and use
**[knitcitations]()** for reference management. Fully developed write-ups may be moved elsewhere.  Both HTML and markdown outputs should be retained in the repository,
so as to keep outputs as the core codebase may change.

References for this project can be found in
[this Paperpile folder](https://paperpile.com/shared/NmMQtu)