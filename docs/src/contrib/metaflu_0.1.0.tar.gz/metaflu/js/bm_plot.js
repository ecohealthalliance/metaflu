(function($) {
    $(document).ready(function() {
	
	$('#bm_plot').scianimator({
	    'images': ['images/bm_plot1.png', 'images/bm_plot2.png', 'images/bm_plot3.png', 'images/bm_plot4.png', 'images/bm_plot5.png', 'images/bm_plot6.png', 'images/bm_plot7.png', 'images/bm_plot8.png', 'images/bm_plot9.png', 'images/bm_plot10.png', 'images/bm_plot11.png', 'images/bm_plot12.png', 'images/bm_plot13.png', 'images/bm_plot14.png', 'images/bm_plot15.png', 'images/bm_plot16.png', 'images/bm_plot17.png', 'images/bm_plot18.png', 'images/bm_plot19.png', 'images/bm_plot20.png', 'images/bm_plot21.png', 'images/bm_plot22.png', 'images/bm_plot23.png', 'images/bm_plot24.png', 'images/bm_plot25.png', 'images/bm_plot26.png', 'images/bm_plot27.png', 'images/bm_plot28.png', 'images/bm_plot29.png', 'images/bm_plot30.png'],
	    'width': 480,
	    'delay': 50,
	    'loopMode': 'loop'
	});
	$('#bm_plot').scianimator('play');
    });
})(jQuery);
