#ifndef INCLUDES
#define INCLUDES

#include <RcppArmadillo.h>
#include <progress.hpp>
#include "data_structures.h"
#include "rates.h"

#endif
